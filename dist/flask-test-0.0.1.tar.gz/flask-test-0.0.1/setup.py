from setuptools import find_packages, setup

print("==================================================")
print(find_packages())
print("==================================================")

setup(
    name="flask-test",
    version="0.0.1",
    author="sw_architecture",
    author_email="seungjoon.oh@kt.com",
    description="python flask sample package",
    url="http://10.217.66.21/devops/newdeal-python-flask-sample",
    packages=find_packages(),
    license="MIT",
    classifiers=[
        "Programming Language :: Python :: 3",
        "License :: OSI Approved :: MIT License",
        "Operating System :: OS Independent",
    ],

    install_requires=[
       'Flask>=0.2',
       'flask-restplus>=0.10',
       'pytest>=5.1.1'
    ],
    setup_requires=[
    ],
    scripts=[
    ],
)
